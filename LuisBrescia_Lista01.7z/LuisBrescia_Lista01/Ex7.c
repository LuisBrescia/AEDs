#include <stdio.h>

// 7) Construa um algoritmo que converte uma temperatura Farenheit em grau Celsius: 

void main (){

    float grausF;
    scanf("%f", &grausF);

    printf("%.2f", 5.0 / 9.0 * (grausF - 32));
}